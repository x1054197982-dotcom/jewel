// React entry point disabled to support single-file HTML mode.
// Check index.html for the main application logic.
